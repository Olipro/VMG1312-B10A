/*
 * (C) 2005 by Pablo Neira Ayuso <pablo@netfilter.org>
 *
 * This software may be used and distributed according to the terms
 * of the GNU General Public License, incorporated herein by reference.
 */

#ifndef _LIBNETFILTER_CONNTRACK_IPV6_H_
#define _LIBNETFILTER_CONNTRACK_IPV6_H_

#warning "Please, remove libnetfilter_conntrack_ipv6.h from your includes!"

#endif
